<?php
/**
 * The template for displaying all single posts.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package VCTheme
 */

get_header(); ?>

<div class="archive-single content-area" id="primary">
	<div class="container">
		<main class="main-content" id="main">
			<?php
			while ( have_posts() ) :
				the_post();

				get_template_part( 'template-parts/content', get_post_type() );

				the_posts_navigation();

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile;
			?>
		</main><!-- #main -->

		<?php get_sidebar(); ?>

	</div><!-- .container -->
</div><!-- .archive-single -->

<?php get_footer(); ?>