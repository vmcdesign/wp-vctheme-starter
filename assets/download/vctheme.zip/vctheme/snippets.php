<?php
/**
 * WORDPRESS SNIPPETS
 * version: 1.0
 *
 * This file contains useful WordPress snippets collected over time.
 * ---------------------------------------------------------------------- */

/**
 * TABLE OF CONTENTS
 *
 * 1.0 Custom Body Classes
 * 	 - Add Custom Body Classes to Pages
 * 	 - Check if a Body Class Exists
 * 2.0 Loops
 *	 - Basic Loop
 *   - Custom Loops
 * ---------------------------------------------------------------------- */


/**
 * 1.0 Custom Body Classes
 *
 * Add a custom body class for certain pages
 * @link https://developer.wordpress.org/reference/functions/body_class/
 * ---------------------------------------------------------------------- */

// Add custom body classes to pages.
function custom_body_classes( $classes ) {
	if ( is_page( array( $id, $slug, $name ) ) ) {
		$classes[] = 'custom-class-1 custom-class-2';
	}
	return $classes;
}

// Check if a body class exists.
$body_classes = get_body_class();
if ( in_array( $class, $body_classes ) ) {
	// Do something...
} else {
	// Do something...
}

/**
 * WordPress Loops
 *
 * This section is dedicated to displaying WordPress loops!
 * @link https://developer.wordpress.org/themes/basics/the-loop/
 * ---------------------------------------------------------------------- */

// Basic loop.
while ( have_posts() ) : the_post();
	get_template_part( $slug, $name );
endwhile;

/**
 * Custom WP loop using WP_Query and taxonomies.
 * See more here: @link https://developer.wordpress.org/reference/classes/wp_query/
 */
$args = array(
	'posts_per_page' => '',
	'category_name'	 => ''
);
$the_query = new WP_Query( $args );

while ( $the_query->have_posts() ) : $the_query->the_post();
	get_template_part( $slug, $name );
endwhile;

// Reset the post data to maintain functionality for additional loops.
wp_reset_postdata();



