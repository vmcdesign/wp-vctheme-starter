# VCTheme

**Contributors:**
**Requires at least:** WordPress 4.4
**Tested up to:** WordPress 4.7
**Stable tag:** 1.0
**Version:** 1.0
**License:** GPLv2 or later
**License URI:** http://www.gnu.org/licenses/gpl-2.0.html
**Tags:** left-sidebar, right-sidebar, custom-background, custom-menu, featured-images, blog, translation-ready, theme-options

A barebones WordPress starter theme for your next project.

## Description

This is the long description.  No limit, and you can use Markdown (as well as in the following sections).

## Frequently Asked Questions

## Copyright

VCTHEME, Copyright 2018 Vanessa Coles
VCTHEME is distributed under the terms of the GNU GPL

VCTHEME bundles the following third-party resources:

normalize.css, Copyright 2012-2016 Nicolas Gallagher and Jonathan Neal
**License:** MIT
Source: https://necolas.github.io/normalize.css/

Font Awesome icons, Copyright Dave Gandy
**License:** SIL Open Font License, version 1.1.
Source: http://fontawesome.io/

Ionicons, Copyright Ionic
**License:** MIT
Source: https://ionicons.com/

## Changelog

### 1.0
* Released:

Initial release
