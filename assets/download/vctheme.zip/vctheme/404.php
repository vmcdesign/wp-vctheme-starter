<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package VCTheme
 */

get_header(); ?>

<div class="page-404 page-default content-area" id="primary">
	<div class="container">
		<main class="main-content" id="main">

			<div class="error-404 not-found">
				<!-- Page header -->
				<header class="page-header">
					<h2 class="page-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'vctheme' ); ?></h2>
				</header>

				<!-- Page content -->
				<div class="page-content">
					<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'vctheme' ); ?></p>

					<?php get_search_form(); ?>
				</div>
			</div>
		</main><!-- #main -->

		<?php get_sidebar(); ?>

	</div><!-- .container -->
</div><!-- .page-404 -->

<?php get_footer(); ?>