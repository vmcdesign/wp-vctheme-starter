<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package VCTheme
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'vctheme' ); ?></a>
	<header id="masthead" class="site-header" role="banner">
		<div class="container">
			<!-- Site Branding -->
			<div class="site-branding">
				<div class="site-logo">
					<?php
					// Get the custom logo.
					$custom_logo = wp_get_attachment_image( get_theme_mod( 'custom_logo' ), 'full' );

					// Display custom logo if it exists, otherwise show site name.
					if ( has_custom_logo() ) : echo $custom_logo; else : ?>
						<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/') ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
					<?php endif; ?>
				</div>
			</div><!-- .site-branding -->

			<!-- Primary Navigation -->
			<nav class="nav" id="primary-nav">
				<?php
				/**
				 * Bootstrap navwalker is available for use with menus.
				 * Must include fallback_cb and walker to make navbars available.
				 * Be sure to update your markup to include Bootstrap relevant classes.
				 */
				wp_nav_menu( array(
					'theme_location'	=> 'primary',
					'depth'				=> 2,
					'container'			=> '',
					'menu_class'		=> 'nav-menu'
				) );
				?>
			</nav><!-- #primary-nav -->
		</div><!-- .container -->
	</header><!-- .site-header -->

	<!-- Site Content -->
	<div id="content" class="site-content">