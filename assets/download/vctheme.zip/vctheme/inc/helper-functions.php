<?php
/**
 * -----------------------------------------------------------------------
 * Helper Functions
 *
 * The code below includes helpful functions, actions, and filters
 * extending theme functionality.
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 * ----------------------------------------------------------------------
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function vctheme_body_classes ( $classes ) {
	// Add a class to pages the include posts.
	if ( is_archive() ) {
		$classes[] = 'page-archive';
	}

	// Adds a class to the homepage.
	if ( is_front_page() ) {
		$classes[] = 'homepage';
	}

	return $classes;
}
add_filter( 'body_class', 'vctheme_body_classes' );

/**
 * Read more link.
 *
 * Filter the excerpt and add a "Read More" link.
 */
function vctheme_excerpt_more( $more ) {
    return '';
}
add_filter( 'excerpt_more', 'vctheme_excerpt_more' );

/**
 * Custom excerpt length.
 *
 * Filters the displayed post excerpt.
 */
function vctheme_custom_excerpt_length ( $length ) {
	return 50; // Set to 50 by default.
}
add_filter( 'excerpt_length', 'vctheme_custom_excerpt_length' );

/**
 * Custom post category counts.
 *
 * Customize category post counts by enclosing them in their own container.
 */
function vctheme_custom_cat_count ( $links ) {
	$links = str_replace( '<a> (', '</a> <span class="cat-post-count">(', $links );
	$links = str_replace( ')', ')</span>', $links );
	return $links;
}
add_filter( 'wp_list_categories', 'vctheme_custom_cat_count' );

/**
 * Customize the widget tag cloud.
 */
function vctheme_widget_tag_cloud_args ( $args ) {
	// $args['unit'] = 12
	$args = array(
		'unit' => 12
	);
	return $args;
}
add_filter( 'widget_tag_cloud_args', 'vctheme_widget_tag_cloud_args' );

/**
 * Extend the WordPress Visual Editor.
 *
 * @link https://codex.wordpress.org/TinyMCE_Custom_Buttons
 */
function vctheme_add_more_buttons( $buttons ) {
	$buttons[] = 'fontselect, styleselect, cut, copy, paste, charmap';
	return $buttons;
}
add_filter( 'mce_buttons', 'vctheme_add_more_buttons' );

/**
 * Customize post formats.
 *
 * @link https://codex.wordpress.org/Post_Formats
 */
if ( has_post_format( 'image' ) ) {
	// Do something...
}

if ( has_post_format( 'gallery' ) ) {
	// Do something...
}

if ( has_post_format( 'audio' ) ) {
	// Do something...
}

if ( has_post_format( 'video' ) ) {
	// Do something...
}

if ( has_post_format( 'quote' ) ) {
	// Do something...
}

if ( has_post_format( 'link' ) ) {
	// Do something...
}