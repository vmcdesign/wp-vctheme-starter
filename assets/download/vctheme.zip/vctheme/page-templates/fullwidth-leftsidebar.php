<?php
/**
 * Template Name: Fullwidth Left Sidebar
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package VCTheme
 */

get_header(); ?>

<div class="page-leftsidebar page-fullwidth page-default content-area" id="primary">
	<div class="container-fluid">

		<?php get_sidebar(); ?>

		<main class="main-content" id="main">
			<?php
			while ( have_posts() ) : the_post();

				get_template_part( 'template-parts/content', 'page' );

			endwhile;
			?>
		</main><!-- #main -->
	</div><!-- .container -->
</div><!-- .page-leftsidebar -->

<?php get_footer(); ?>