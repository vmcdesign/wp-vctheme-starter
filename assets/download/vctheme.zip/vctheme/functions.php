<?php
/**
 * -----------------------------------------------------------------------
 * Theme Functions and Definitions - Defaults
 *
 * Can copy and paste this content into your functions.php file.
 * Find and replace the default "vctheme" with your theme's textdomain.
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 * ----------------------------------------------------------------------
 */

// This theme only works in WordPress 4.7 or later.

if ( ! function_exists( 'vctheme_setup' ) ) :

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function vctheme_setup () {
	/**
	 * Make theme available for translation.
	 * Translations can be filed at WordPress.org. See: https://translate.wordpress.org/projects/wp-themes/twentyseventeen
	 * If you're building a theme based on Twenty Seventeen, use a find and replace
	 * to change 'twentyseventeen' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'vctheme' );

	/**
	 * Add default posts and comments RSS feed links to head.
	 */
	add_theme_support( 'automatic-feed-links' );

	/**
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/**
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	/**
	 * Enable support for Custom Backgrounds for your theme.
	 *
	 * @link https://developer.wordpress.org/reference/functions/add_theme_support/#custom-background
	 */
	add_theme_support( 'custom-background', array(
		'default-image'			=> '',
		'default-color'			=> 'white',
		'default-preset'		=> 'default',
		'default-position-y'	=> 'top',
		'default-position-x' 	=> 'left',
		'default-size'			=> 'auto',
		'default-repeat'		=> 'repeat',
		'default-attachment'	=> 'scroll'
	) );


	/**
     * Enable support for a Custom Logo and provide theme defaults
     *
     * @link https://developer.wordpress.org/themes/functionality/custom-logo/
     */
	add_image_size( 'custom-logo', 75, 75 );
	add_theme_support( 'custom-logo', array (
		'size' => 'custom-logo'
	) );

	/**
	 * Add additional image sizes.
	 *
	 * @link https://developer.wordpress.org/reference/functions/add_image_size/
	 */
	add_image_size( '$name', $width = 0, $height = 0, $crop = false );

	/**
	 * Register theme menus.
	 */
	register_nav_menus( array(
		'primary'		=> __( 'Primary Navigation', 'vctheme' ),
		'footer'		=> __( 'Footer Links', 'vctheme' )
	) );

	/**
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'comment-form',
		'comment-list',
		'gallery',
		'caption'
	) );

	/**
	 * Enable support for Post Formats.
	 *
	 * @link https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'audio',
		'gallery',
		'link',
		'image',
		'quote',
		'video'
	) );

	/**
	 * Define content width.
	 */
	if ( ! isset( $content_width ) ) $content_width = 960;

	/**
	 * Add theme support for selective refresh widgets.
	 */
	add_theme_support( 'customize-selective-refresh-widgets' );

}
endif; // End vctheme_setup ()
add_action( 'after_setup_theme', 'vctheme_setup' );

/**
 * Register default sidebar.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function vctheme_sidebar_init () {
	register_sidebar( array(
		'name'			=> __( 'Default Sidebar', 'vctheme' ),
		'id'			=> 'sidebar-1',
		'description'	=> __( 'Add widgets here to appear in your default sidebar.', 'vctheme' ),
		'before_widget'	=> '<div id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</div>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_widget'	=> '</h3>'
	) );
}
add_action( 'widgets_init', 'vctheme_sidebar_init' );

/**
 * Register additional widgets.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function vctheme_widgets_init () {
	// Register additional widgets herre...
}
add_action( 'widgets_init', 'vctheme_widgets_init' );

/**
 * Add .js script if "Enable threaded comments" is activated in WordPress Admin.
 *
 * Codex: @link https://developer.wordpress.org/reference/functions/wp_enqueue_script/
 */
function vctheme_enqueue_comments_reply () {
	if ( is_singular() && comments_open() && ( get_option( 'thread_comments') == 1 ) ) {
		// Load comment-reply.js in the footer.
		wp_enqueue_script( 'comment-reply', 'wp-includes/js/comment-reply', array(), false, true );
	}
}
add_action( 'wp_enqueue_scripts', 'vctheme_enqueue_comments_reply' );

/**
 * Allow the use of shortcodes in text widgets.
 */
add_filter( 'widget-text', 'do_shortcode' );

/**
 * -----------------------------------------------------------------------
 * Theme Customization (Optional!)
 *
 * The code below includes your fonts, scripts, and styles.  Bootstrap
 * included by default.
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 * ----------------------------------------------------------------------
 */

/**
 * Load Bootstrap Core.
 *
 * @link https://getbootstrap.com
 */
function vctheme_load_bootstrap_core () {
	wp_enqueue_script( 'bootstrap-popper-script', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js', array( 'jquery' ), '', '', true );
	wp_enqueue_script( 'bootstrap-script', 'https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js', array( 'jquery' ), '', '', true  );
	wp_enqueue_style( 'bootstrap-style', 'https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css' );
}
add_action( 'wp_enqueue_scripts', 'vctheme_load_bootstrap_core' );

/**
 * Add Google Fonts to your theme.
 */
function vctheme_load_google_fonts () {
	// Import the fonts
	$query_args = array(
		'family'	=> '',
		'subset'	=> 'latin,latin-ext'
	);

	// Register the fonts
	wp_enqueue_style( 'google-fonts-style', add_query_arg( $query_args ), '//fonts.googleapis.com/css' );
}
add_action( 'wp_enqueue_scripts', 'vctheme_load_google_fonts' );

/**
 * Add icon fonts to your theme.
 *
 * Ionicons and Fontawesome included by default.
 * @link
 */
function vctheme_load_icon_fonts () {
	// Register the scripts and styles making them readily available.
	wp_register_script( 'ionicons-script', 'https://unpkg.com/ionicons@4.2.5/dist/ionicons.js', '', '', true );
	wp_register_script( 'fontawesome-script', 'https://use.fontawesome.com/releases/v5.2.0/js/all.js', '', '', true );
	wp_register_style( 'fontawesome-v5.2.0', 'https://use.fontawesome.com/releases/v5.2.0/css/all.css' );

	// Enqueue all the scripts and styles.
	wp_enqueue_script( 'ionicons-script' );
	wp_enqueue_script( 'fontawesome-script' );
	wp_enqueue_style( 'fontawesome-style' );
}
add_action( 'wp_enqueue_scripts', 'vctheme_load_icon_fonts' );

/**
 * Enqueue scripts and styles.
 *
 * @link https://developer.wordpress.org/reference/functions/wp_enqueue_style/
 */
function vctheme_scripts () {
	// Scripts
	wp_enqueue_script( 'vctheme-script', get_stylesheet_directory_uri() . '/assets/js/script.js', array( 'jquery'), '', true );
	// Styles
	wp_enqueue_style( 'vctheme-style', get_stylesheet_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'vctheme_scripts' );

/**
 * Include helper functions for further theme customization.
 */
require get_template_directory() . '/inc/helper-functions.php';

/**
 * Include the Bootstrap 4 navwalker.
 */
require get_template_directory() . '/inc/plugins/bs4-navwalker.php';