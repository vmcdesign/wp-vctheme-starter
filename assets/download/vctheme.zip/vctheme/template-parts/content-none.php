<?php
/**
 * Template part for displaying a message that posts cannot be found.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package VCTheme
 */
?>

<!-- Page Header -->
<header class="page-header">
	<h2 class="page-title"><?php esc_html_e( 'Nothing Found', 'vctheme' ); ?></h2>
</header><!-- .page-header -->

<!-- Page Content -->
<div class="no-results not-found">
	<div class="page-content">
		<?php if ( is_search() ) : ?>

			<p><?php esc_html_e( "Sorry, but we couldn't find what you were looking for, please try again with some different terms.", 'vctheme' ); ?></p>

			<?php

			get_search_form();

		else : ?>

			<p><?php esc_html_e( "Sorry, but we couldn't find what you were looking for.  Maybe searching can help.", 'vctheme' ); ?></p>

			<?php

			get_search_form();

		endif; ?>
	</div><!-- .page-content -->
</div><!--- .no-results -->

<!-- Page Footer -->
<div class="page-footer entry-footer">
	<?php
	edit_post_link( __( 'Edit', 'vctheme' ), '<p>', '</p>', null, 'edit-post-link' );
	?>
</div><!-- .page-footer -->
