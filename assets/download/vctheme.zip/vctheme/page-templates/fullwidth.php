<?php
/**
 * Template Name: Fullwidth
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package VCTheme
 */

get_header(); ?>

<div class="page-fullwidth page-default content-area" id="primary">
	<div class="container-fluid">
		<main class="main-content" id="main">
			<?php
			while ( have_posts() ) : the_post();

				get_template_part( 'template-parts/content', 'page' );

			endwhile;
			?>
		</main><!-- #main -->

		<?php get_sidebar(); ?>

	</div><!-- .container-fluid -->
</div><!-- .page-fullwidth -->

<?php get_footer(); ?>