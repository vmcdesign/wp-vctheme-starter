<?php
/**
 * Template Name: Fullwidth No Sidebar
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package VCTheme
 */

get_header(); ?>

<div class="page-fullwidth page-nosidebar page-default content-area"  id="primary">
	<div class="container-fluid">
		<main class="main-content" id="main">
			<?php
			while ( have_posts() ) : the_post();

				get_template_part( 'template-parts/content', 'page' );

			endwhile;
			?>
		</main><!-- #main -->
	</div><!-- .container-fluid -->
</div><!-- .page-fullwidth-nosidebar -->

<?php get_footer(); ?>