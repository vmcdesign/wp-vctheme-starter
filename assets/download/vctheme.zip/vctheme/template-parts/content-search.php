<?php
/**
 * Template part for displaying results in search pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package VCTheme
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<!-- Entry Header -->
	<div class="entry-header">
		<?php
		if ( is_singular() ) :
			the_title( '<h2 class="entry-title">', '</h2>' );
		else :
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>');
		endif;
		?>
	</div><!-- .entry-header -->

	<!-- Entry Meta -->
	<div class="entry-meta">
		<div class="meta-item meta-time">
			<strong>Posted on:</strong>
			<span><?php the_time( 'F jS, Y' ); ?></span>
		</div>
		<div class="meta-item meta-author">
			<strong>Author:</strong>
			<span><?php the_author(); ?></span>
		</div>
		<div class="meta-item meta-category">
			<strong>Category:</strong>
			<span><?php the_category( ' , ' ); ?></span>
		</div>
		<div class="meta-item meta-tags">
			<strong>Tagged:</strong>
			<span><?php the_tags(); ?></span>
		</div>
	</div><!-- .entry-meta -->

	<!-- Entry Content -->
	<div class="entry-content">
		<?php
		the_excerpt();

		wp_link_pages( array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'vctheme' ),
			'after'  => '</div>',
		) );
		?>
		<div class="read-more">
			<a href="<?php the_permalink(); ?>" class="read-more-link"><?php echo __( 'Continue Reading...', 'vctheme' ); ?></a>
		</div>
	</div><!-- .entry-content -->
</article><!-- .post -->